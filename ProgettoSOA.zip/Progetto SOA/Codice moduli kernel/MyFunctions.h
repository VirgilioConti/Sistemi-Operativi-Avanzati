/*
 * MyFunctions.h
 *
 *  Created on: 15 Mar 2022
 *      Author: virgilio
 */

#ifndef MYFUNCTIONS_H_
#define MYFUNCTIONS_H_


int count_items_waitqueue(struct wait_queue_head * wq);


int findMin(int a, int b);

#endif /* MYFUNCTIONS_H_ */
