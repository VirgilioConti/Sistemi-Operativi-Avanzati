/*
 * ModOnOff.c
 *
 *  Created on: 14 Mar 2022
 *      Author: virgilio
 */


#include <linux/module.h>
#include <linux/init.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Virgilio");
MODULE_DESCRIPTION("Module to enable or disable a device by means of Minor!");

extern int* dev_on_off;


int minor;
module_param(minor,int,0644 );

int on_off;                // on_off=0 enabled ** on_off=1 disabled
module_param(on_off,int,0644 );

void func_on_off_device(int minor,int status_device){

	dev_on_off[minor]=status_device;

}


int myModuleInit(void){

	printk("Init function ModOnOff module\n");
	func_on_off_device( minor, on_off);

	return 0;
}

void myModuleExit(void){
	printk("Exit function ModOnOff module\n");
}

module_init(myModuleInit);

module_exit(myModuleExit);
