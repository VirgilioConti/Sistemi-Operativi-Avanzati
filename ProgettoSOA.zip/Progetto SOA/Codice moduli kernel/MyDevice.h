/*
 * MyDevice.h
 *
 *  Created on: 15 Mar 2022
 *      Author: virgilio
 */

#ifndef MYDEVICE_H_
#define MYDEVICE_H_

#include <linux/cdev.h>
#include <linux/mutex.h>

#include "MyQueuek.h"

#define MY_MAJOR 100
#define MAX_NUMBER_OF_MINORS 128
#define MY_DRIVER_NAME "my_driver"
#define MAX_SIZE_MSG_QUEUE_LP_WRITE 30
#define TIMEOUT_BLOCKIN_OP  2000  //2000 milliseconds default value
#define PERIOD_UPDATE 10  // used in kernel thread functions

struct my_device{
	struct cdev char_dev;

	Queue High_priority_queue_R;
	Queue Low_priority_queue_R;
	Queue High_priority_queue_W;
	Queue Low_priority_queue_W;

	struct mutex HP_read;
	struct mutex LP_read;
	struct mutex HP_write;
	struct mutex aux;

	wait_queue_head_t *my_waitqueueHP_R;
	wait_queue_head_t *my_waitqueueLP_R;
	wait_queue_head_t *my_waitqueueHP_W;
	wait_queue_head_t *my_waitqueueLP_W;

	Msg *Temporary_Queue;
	unsigned int size_temporary_Msg_queue;

};
typedef struct my_device my_device;



#endif /* MYDEVICE_H_ */
