/*
 * MyQueueK.c
 *
 *  Created on: 7 Mar 2022
 *      Author: virgilio
 */

#include <linux/module.h>
#include <linux/init.h>
#include <linux/string.h>
#include <linux/slab.h>
#include <linux/gfp.h>
#include "MyQueuek.h"

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Virgilio");
MODULE_DESCRIPTION("Module to handle queue!");

int initializeQueue( Queue *myQueue,unsigned int mysize,char *name){

	(*myQueue).queue=(Msg *) kmalloc(mysize*sizeof(Msg),GFP_KERNEL);
	(*myQueue).indexCurrentSize=0;
	(*myQueue).size= mysize;
	sprintf( (*myQueue).name,"%s", name);

	printk("Queue *%s* initialized OK size=%d !!\n",(*myQueue).name,(*myQueue).size);

	return 0;
}

int insertElemIntoQueue( Queue *myQueue, Msg elem){  // altgr + 7 = {     altgr + 0 = }

    int position;
    position= (*myQueue).indexCurrentSize;

    if(position>=(*myQueue).size){
       printk("Queue *%s*is completely full!!\n",(*myQueue).name);
       position=( (*myQueue).size-1 );
       return 0;
    }

	if(position>=0 && position<(*myQueue).size){
		( (*myQueue).queue)[position] = elem;
		printk("Element inserted in queue position %d\n",position);

		(*myQueue).indexCurrentSize++;

		return 0;
	}


	printk("Cannot insert msg into queue: index=%d too big or too small!!\n",(*myQueue).indexCurrentSize);
	return  -1;
}

Msg readMessageFromQueue(Queue *myQueue){
	int position;
	Msg msg;
    int i=0;


    position= (*myQueue).indexCurrentSize;

    if(position<0){
       position=0;
       printk("Queue *%s*is empty!!\n",(*myQueue).name);
       return msg;
    }

	if(position>=0 && position<(*myQueue).size){

		  msg=( (*myQueue).queue)[0];     //first element of queue
		  printk("Element read in queue!!\n");

		  for(i=0;i<(position-1);i++){   // move all the messages in queue toward the left
		  	  ( (*myQueue).queue)[i]=( (*myQueue).queue)[i+1];
		  }

		  sprintf( (((*myQueue).queue)[i]).msg, "\0");
		  (*myQueue).indexCurrentSize--;

		  return msg;
	}


	printk("Cannot read msg from queue: index=%d too big or too small!!\n",(*myQueue).indexCurrentSize);
	return msg;
}

int GetSize_Message(Msg message){

	int size_msg;

	size_msg=strlen(message.msg);

	printk("Size message in queue: %d\n",size_msg);

	return size_msg;
}

int HowManybytesInQueue(Queue *myQueue){

	int size_q= (*myQueue).indexCurrentSize;
	int bytes_in_queue=0;
	int i=0;


	for(i=0;i<size_q;i++){
		bytes_in_queue+=GetSize_Message( (*myQueue).queue[i] );
	}

	printk("Bytes in queue *%s*: %d\n",(*myQueue).name,bytes_in_queue);
	return bytes_in_queue;
}

void ShowNmessages(Queue myQueue, unsigned int Nmsg){
	unsigned int size = myQueue.size;
	int i;
	Msg messaggio;

	if(Nmsg>size){
		Nmsg=size;
	}

	if(Nmsg<=size){
	   for(i=0;i<Nmsg;i++){
	      messaggio=(myQueue.queue)[i];
          printk("msg %d:%s\n",i,messaggio.msg);

       }
	   return;
	}

	printk("Something wrong in function ShowNmessages()\n");
}
