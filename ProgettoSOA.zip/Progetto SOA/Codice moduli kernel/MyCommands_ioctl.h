/*
 * MyIOctl.h
 *
 *  Created on: 3 Mar 2022
 *      Author: virgilio
 */


#ifndef MYCOMMANDS_IOCTL_H_
#define MYCOMMANDS_IOCTL_H_

#define BLOCKING_READ_HP 0
#define BLOCKING_READ_LP 1

#define BLOCKING_WRITE 2

#define NOT_BLOCKING_WRITE 3


#endif /* MYCOMMANDS_IOCTL_H_ */
