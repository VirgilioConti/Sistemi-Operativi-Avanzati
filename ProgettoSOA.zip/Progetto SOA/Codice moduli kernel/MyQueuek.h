/*
 * MyQueue.h
 *
 *  Created on: 3 Mar 2022
 *      Author: virgilio
 */

#ifndef MYQUEUEK_H_
#define MYQUEUEK_H_

#define MAX_MESSAGE_SIZE 20
#define MAX_NAME_QUEUE_SIZE 50

struct messaggio{
	char msg[MAX_MESSAGE_SIZE];
};
typedef struct messaggio Msg;

 struct Queue{
	char name[MAX_NAME_QUEUE_SIZE];
	Msg *queue;
    int  indexCurrentSize;     //it tells me how many messages there are currently in queue
	unsigned int size;           // full capacity of queue that is constant over time
};
typedef struct Queue Queue;


int initializeQueue( Queue *myQueue,unsigned int mysize,char *name);
int insertElemIntoQueue( Queue *myQueue, Msg elem);
Msg readMessageFromQueue(Queue *myQueue);
int GetSize_Message(Msg message);
int HowManybytesInQueue(Queue *myQueue);
void ShowNmessages(Queue myQueue, unsigned int Nmsg);


#endif /* MYQUEUEK_H_ */
