/*
 * MyFunctions.c
 *
 *  Created on: 15 Mar 2022
 *      Author: virgilio
 */
#include <linux/module.h>
#include <linux/init.h>
#include <linux/kthread.h>
#include <linux/wait.h>




MODULE_LICENSE("GPL");
MODULE_AUTHOR("Virgilio");
MODULE_DESCRIPTION("Module with my functions defined by me!");




int count_items_waitqueue(struct wait_queue_head * wq) {

  struct list_head * aux= &((*wq).head) ;
  int i = 0;

  while (aux != NULL) {
    aux = (*aux).next;
    i++;
  }
  return i;
}



int findMin(int a, int b){

	if(a<=b){
		return a;
	}
	else{
		return b;
	}
}
