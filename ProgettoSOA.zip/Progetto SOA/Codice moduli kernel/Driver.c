/*
 * Driver.c
 *
 *  Created on: 2 Mar 2022
 *      Author: virgilio
 */

#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/ioctl.h>
#include <linux/cdev.h>
#include <linux/uaccess.h>  //def of copy from/to user functions
#include <linux/slab.h>     // for kmalloc()
#include <linux/gfp.h>
#include <linux/kernel.h>  // definition of container_of macro
#include <linux/moduleparam.h>
#include <linux/stat.h>
#include <linux/mutex.h>
#include <linux/kthread.h>
#include <linux/sched.h>
#include <linux/wait.h>
#include <linux/delay.h>
#include <linux/jiffies.h>
#include "MyCommands_ioctl.h"
#include "MyDevice.h"
#include "MyFunctions.h"
#include "MyQueuek.h"

#define MAX_VALUE_UNSIGNEDINT 4294967295

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Virgilio");
MODULE_DESCRIPTION("My first driver to do!");



////////////////////////MODULE PARAMETERS//////////////////////////////////////////////

int n_devs;                            // n_devs=number of devices
module_param(n_devs,int,0644);

int length_queues;                       // lenght of queue equal for every device
module_param(length_queues,int,0644);

int IsDeviceOnOff[MAX_NUMBER_OF_MINORS];                //0=device enabled  1=device disabled
module_param_array(IsDeviceOnOff,int,&n_devs,0644);
/////////////////////////////////////////////////
/////////////////////////////////////////////////
int BytesInHPqueueR[MAX_NUMBER_OF_MINORS];            //number of bytes in high priority read queue
module_param_array(BytesInHPqueueR,int,&n_devs,0644);

int BytesInLPqueueR[MAX_NUMBER_OF_MINORS];           //number of bytes in low priority read queue
module_param_array(BytesInLPqueueR,int,&n_devs,0644);

int BytesInHPqueueW[MAX_NUMBER_OF_MINORS];           //number of bytes in high priority write queue
module_param_array(BytesInHPqueueW,int,&n_devs,0644);

int BytesInLPqueueW[MAX_NUMBER_OF_MINORS];          //number of bytes in low priority read queue
module_param_array(BytesInLPqueueW,int,&n_devs,0644);
//////////////////////////////////////////////
///////////////////////////////////////////////
int ThreadsInHPqueueR[MAX_NUMBER_OF_MINORS];        //number of waiting threads in high priority read queue
module_param_array(ThreadsInHPqueueR,int,&n_devs,0644);

int ThreadsInLPqueueR[MAX_NUMBER_OF_MINORS];        //number of waiting threads in low priority read queue
module_param_array(ThreadsInLPqueueR,int,&n_devs,0644);

int ThreadsInHPqueueW[MAX_NUMBER_OF_MINORS];       //number of waiting threads in high priority write queue
module_param_array(ThreadsInHPqueueW,int,&n_devs,0644);

int ThreadsInLPqueueW[MAX_NUMBER_OF_MINORS];      //number of waiting threads in low priority write queue
module_param_array(ThreadsInLPqueueW,int,&n_devs,0644);


////////////////////////////DIAGNOSTICS KERNEL THREADS///////////////////////////////////////////

struct task_struct *th_diagnostics;     //thread to calculate number of bytes of queues
struct task_struct *th_diagnostics2;    //thread to calculate waiting threads of queues
struct task_struct *th_deferred_writes; //thread to handle deferred writes in queues

int th_diagnostics_func(void *data);   // prototype of functions that threads execute respectively
int th_diagnostics_func2(void *data);
int th_deferred_writes_func( void* data);

//////////EXPORT FOR MODULE IN CHARGE OF TURNING ON-OFF A DEVICE/////////////////////////////////////////////////

int *dev_on_off=&IsDeviceOnOff[0];
EXPORT_SYMBOL(dev_on_off);


///////////////////////////CONTROL VARIABLE FOR IOCTL()/////////////////////////////////////////////////
int blocking_read_hp=-1;
int blocking_read_lp=-1;
int blocking=-1;              //0=blocking  1=not_blocking
int not_blocking=-1;
unsigned long timerJiffies;   //timer for blocking operations
int id=0;                    //index used for data in temporary buffer for low priority writes


////////////////////MY DEVICES////////////////////////////////////////

struct my_device *devs;


//////////////////////MY DRIVER/////////////////////////////////////////
int myopen(struct inode *inode, struct file *file){

	my_device *my_dev=container_of( (*inode).i_cdev ,my_device,char_dev);

	dev_t MAJ_min=(*inode).i_rdev;

    unsigned int minor=MINOR(MAJ_min);

	if(IsDeviceOnOff[minor]==0){
       (*file).private_data=my_dev;
       printk("Device minor %d enabled\n",minor);
	}else{
		printk("Device minor %d disabled\n",minor);
	}

	printk("my module open function\n");
	return 0;
}

int myclose(struct inode *inode, struct file *file){

	(*file).private_data=NULL;

	printk("my module close function\n");

	return 0;
}

ssize_t myread(struct file *file, char __user *user_buffer, size_t size, loff_t *offs){

    my_device *my_device=(struct my_device*) (*file).private_data;
    int err; int bytes_to_return;

    Msg message;
    printk("/n");

    bytes_to_return=findMin(size , MAX_MESSAGE_SIZE);
    if(blocking_read_hp==1){

    	message=readMessageFromQueue(  &((*my_device).High_priority_queue_R) );
        printk("messageR_HP: *%s*\n",message.msg);


    	err=copy_to_user(user_buffer, &(message.msg) , bytes_to_return);//copy_to_user(to, from, n)
    	if(err<0){
    		printk("HP_read failed res: %d!!\n", err);

    	}
    mutex_unlock( &((*my_device).HP_read) );
    return 0;
    }//if

    if( blocking_read_lp==1){

    	message=readMessageFromQueue(  &((*my_device).Low_priority_queue_R) );
    	printk("messageR_LP: *%s*\n",message.msg);

        err=copy_to_user(user_buffer, &(message.msg), bytes_to_return);

        if(err<0){
        	printk("LP_read failed res: %d!!\n", err);

        }

    mutex_unlock( &((*my_device).LP_read) );
    return 0;
    }//if


	printk("my module read function!!\n");
	printk("\n");
	return 0;
}

ssize_t mywrite(struct file *file, const char __user *user_buffer, size_t size, loff_t *offs){

	my_device *my_device=(struct my_device*) (*file).private_data;
	int err; int bytes_to_return;

	Msg message;

	printk("\n");
	bytes_to_return=findMin(size , MAX_MESSAGE_SIZE);
	if(blocking==1){

		err=copy_from_user( &(message.msg),user_buffer , bytes_to_return);//copy_from_user(to, from, n)
		if(err<0){
			printk("HP_write failed res: %d!!\n", err);
			mutex_unlock( &((*my_device).HP_write) );
			return 0;
	    }
		printk("messageW_HP: *%s*\n",message.msg);
		insertElemIntoQueue(  &((*my_device).High_priority_queue_W), message );


    mutex_unlock( &((*my_device).HP_write) );
    return 0;
    }//if


	if(not_blocking==1){
		err=copy_from_user( &(( (*my_device).Temporary_Queue)[id].msg),user_buffer , bytes_to_return);//copy_from_user(to, from, n)
		if(err<0){
			printk("LP copy_from_user failed res: %d!!\n", err);
			mutex_unlock( &((*my_device).aux)  );
			return 0;
	    }

	  mutex_unlock( &((*my_device).aux) );
	  return 0;
	}//if

	printk("my module write function!!\n");
	printk("\n");
	return 0;
}

long myioctl(struct file *file, unsigned int cmd, unsigned long arg){

	my_device *my_device=(struct my_device*) (*file).private_data;

	int isMutexRead_HP_locked;
	int isMutexRead_LP_locked;
	int isMutexWritelocked;
    unsigned int size_temp_queue_messages= (*my_device).size_temporary_Msg_queue;


	printk("my module ioctl function!!  ");

	if(arg>0 && arg<MAX_VALUE_UNSIGNEDINT){
	    timerJiffies= msecs_to_jiffies( (unsigned int)arg);
	    printk("msec=%lu ==> jiffies=%lu\n",arg,timerJiffies);
	}else{
	    printk("Wrong value when you set timeout in ioctl drviver!!\n");
	    printk("Timeout value in ioctl driver set to default!!\n");
	    timerJiffies=msecs_to_jiffies(TIMEOUT_BLOCKIN_OP);
    }


    switch(cmd){

      case BLOCKING_READ_HP:

    	   isMutexRead_HP_locked=mutex_is_locked( &((*my_device).HP_read) );

    	   while( isMutexRead_HP_locked){

              wait_event_interruptible_timeout( *((*my_device).my_waitqueueHP_R) ,isMutexRead_HP_locked==0,timerJiffies);
              isMutexRead_HP_locked=mutex_is_locked( &((*my_device).HP_read) );

    	   }

    	   mutex_lock( &((*my_device).HP_read) );
    	   printk("blocking read_HP %d\n",BLOCKING_READ_HP);

    	  blocking_read_hp=1;
    	  blocking_read_lp=0;


          break;

      case BLOCKING_READ_LP:

    	  isMutexRead_LP_locked=mutex_is_locked( &((*my_device).LP_read) );

    	  while( isMutexRead_LP_locked ){

    		wait_event_interruptible_timeout( *((*my_device).my_waitqueueLP_R) ,isMutexRead_LP_locked==0,timerJiffies);
    		isMutexRead_LP_locked=mutex_is_locked( &((*my_device).LP_read) );

    	  }

    	  mutex_lock( &((*my_device).LP_read) );
    	  printk("blocking read_HP %d\n",BLOCKING_READ_LP);

    	  blocking_read_hp=0;
    	  blocking_read_lp=1;

    	 break;

      case BLOCKING_WRITE:

    	  isMutexWritelocked=mutex_is_locked( &((*my_device).HP_write) );

    	  while( isMutexWritelocked ){

    		  wait_event_interruptible_timeout( *((*my_device).my_waitqueueHP_W) ,isMutexWritelocked==0,timerJiffies);
    		  isMutexWritelocked=mutex_is_locked( &((*my_device).HP_write) );

    	  }

    	  mutex_lock( &((*my_device).HP_write) );

    	  printk("blocking write %d\n",BLOCKING_WRITE);
    	  blocking=1;
    	  not_blocking=0;

          break;

      case NOT_BLOCKING_WRITE:
    	  printk("not blocking write %d\n",NOT_BLOCKING_WRITE);

    	  mutex_lock(&((*my_device).aux) );
    	  blocking=0;
    	  not_blocking=1;

    	  id=id+1;
    	  id=(id)%(size_temp_queue_messages); // index of message to store in temporary buffer
                                              // for deferred low priority write
          break;


    }

	return 0;
}


/////////////////////////STRUCT FILE OPERATIONS///////////////////////////////////

struct file_operations fops = {
 		.owner = THIS_MODULE,
 		.open = myopen,
 		.release = myclose,
 		.read = myread,
 		.write = mywrite,
 		.unlocked_ioctl= myioctl
 };


////////////////////////////INIT AND EXIT MODULE FUNCTIONS//////////////////////////////////////////////

int myModuleInit(void){

	int res;  // variable to store return value
	int i=0;
	char name_queue[MAX_NAME_QUEUE_SIZE];
	unsigned int size_temp_q;              // size temporary buffer

	printk("my module init function!!\n");
	if(n_devs>MAX_NUMBER_OF_MINORS){     //make sure number devices are not greater than 128
		n_devs=MAX_NUMBER_OF_MINORS;
	}

	devs=(struct my_device*) kmalloc( n_devs*sizeof(struct my_device),GFP_KERNEL );


	for(i = 0; i < n_devs; i++) { // initialize every field struct my_device

		sprintf(name_queue,"HP_Queue_R%d",i);
		initializeQueue( &(devs[i].High_priority_queue_R),length_queues,name_queue);

		sprintf(name_queue,"LP_Queue_R%d",i);
		initializeQueue( &(devs[i].Low_priority_queue_R),length_queues,name_queue);

		sprintf(name_queue,"HP_Queue%d_W",i);
		initializeQueue( &(devs[i].High_priority_queue_W),length_queues,name_queue);

		sprintf(name_queue,"LP_Queue%d_W",i);
		initializeQueue( &(devs[i].Low_priority_queue_W),length_queues,name_queue);

		mutex_init( &(devs[i].HP_read) );
		mutex_init( &(devs[i].HP_write) );
		mutex_init( &(devs[i].LP_read) );
		mutex_init( &(devs[i].aux) );

		init_waitqueue_head( devs[i].my_waitqueueHP_R);
	    init_waitqueue_head( devs[i].my_waitqueueLP_R);
		init_waitqueue_head( devs[i].my_waitqueueHP_W);
		init_waitqueue_head( devs[i].my_waitqueueLP_W);

		devs[i].size_temporary_Msg_queue=(length_queues/2);
		size_temp_q=(length_queues/2);

		devs[i].Temporary_Queue=(Msg *) kmalloc( size_temp_q * sizeof(Msg),GFP_KERNEL );

    }//for



    res = register_chrdev_region( MKDEV(MY_MAJOR,0) , n_devs, MY_DRIVER_NAME);

    if(res<0){
      	printk("registration driver failed!!\n");
      	return res;
    }


    for(i = 0; i < n_devs; i++) {

       cdev_init( &(devs[i].char_dev), &fops);
       cdev_add( &(devs[i].char_dev), MKDEV(MY_MAJOR, i), 1);
    }



    th_diagnostics= kthread_run(th_diagnostics_func,NULL,"th_diagnostics_func");
    if(th_diagnostics==NULL){
       printk("thread diagnostics not created!!\n");
    }
    th_diagnostics2= kthread_run(th_diagnostics_func2,NULL,"th_diagnostics_func2");
    if(th_diagnostics2==NULL){
       printk("thread diagnostics 2 not created!!\n");
    }
    th_deferred_writes= kthread_run(th_deferred_writes_func,NULL,"th_deferred_writes_func");
    if(th_deferred_writes==NULL){
       printk("thread deferred_writes not created!!\n");
    }

    printk("Registration driver OK!!\n");
	return 0;
}

void myModuleExit(void){
	int i=0;

	printk("my module exit function!!\n");

	unregister_chrdev_region( MKDEV(MY_MAJOR,0),n_devs);

	for(i = 0; i < n_devs; i++) {

		cdev_del( &(devs[i].char_dev) );
    }

	kfree(devs);

    kthread_stop(th_diagnostics);
    kthread_stop(th_diagnostics2);
	kthread_stop(th_deferred_writes);

	printk("driver unregistered!!\n");
}

module_init(myModuleInit);

module_exit(myModuleExit);

///////////////////////////////////THREAD FUNCTIONS//////////////////////////////////

int th_diagnostics_func(void *data){    //calculate the number of bytes for every device

	int i=0;

	printk("thread diagnostics is running!!\n");

	while(!kthread_should_stop()){
		ssleep(PERIOD_UPDATE);

		for(i=0;i<n_devs;i++){
			BytesInHPqueueR[i]=HowManybytesInQueue( &( (devs[i]).High_priority_queue_R ) );
			BytesInLPqueueR[i]=HowManybytesInQueue( &( (devs[i]).Low_priority_queue_R) ) ;
			BytesInHPqueueW[i]=HowManybytesInQueue( &( (devs[i]).High_priority_queue_W ) );
			BytesInLPqueueW[i]=HowManybytesInQueue( &( (devs[i]).Low_priority_queue_W) ) ;

		}
		i=0;
	}

	printk("thread diagnostics stopped!!\n");
	do_exit(0);

	return 0;
}

int th_diagnostics_func2(void *data){  //calculate the number of waiting threads for every device


	int i=0;

	printk("thread diagnostics 2 is running!!\n");

	while(!kthread_should_stop()){
		ssleep(PERIOD_UPDATE);

		for(i=0;i< n_devs;i++){
			ThreadsInHPqueueR[i]=count_items_waitqueue( devs[i].my_waitqueueHP_R );
			ThreadsInLPqueueR[i]=count_items_waitqueue( devs[i].my_waitqueueLP_R);
			ThreadsInHPqueueW[i]=count_items_waitqueue( devs[i].my_waitqueueHP_W );
			ThreadsInLPqueueW[i]=count_items_waitqueue( devs[i].my_waitqueueLP_W);
		}
		i=0;
	}

	printk("thread diagnostics 2 stopped!!\n");
	do_exit(0);

	return 0;
}


// function used only by th_deferred_writes_func
int write_messages_in_LP_Queue(Msg *temp_messages_queue,unsigned int size_temp_q ){

	int i;

    for(i=0;i<size_temp_q;i++){
       insertElemIntoQueue( &(devs[i].Low_priority_queue_W), temp_messages_queue[i] );
       sprintf(temp_messages_queue[i].msg,"\0");
    }

	return 0;
}

int th_deferred_writes_func( void* data){

	int i=0;

	printk("thread deferred_writes is running!!\n");

		while(!kthread_should_stop()){
			ssleep(PERIOD_UPDATE);

			for(i=0;i<n_devs;i++){

			// condition about the filling level mentioned by my report, section called "Deferred work"
              if( devs[i].Low_priority_queue_W.indexCurrentSize < devs[i].size_temporary_Msg_queue ){
                 write_messages_in_LP_Queue( devs[i].Temporary_Queue,devs[i].size_temporary_Msg_queue );
              }
			}
			i=0;
		}

	printk("thread deferred_writes stopped!!\n");
	do_exit(0);
	return 0;
}

