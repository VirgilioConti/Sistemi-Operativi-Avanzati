/*
 * rngs.h
 *
 *  Created on: 7 Oct 2020
 *      Author: virgilio
 */

#ifndef RNGS_H_
#define RNGS_H_


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * File:   rngs.h
 * Author: virgilio
 *
 * Created on 1 ottobre 2020, 21:56
 */

#ifndef RNGS_H
#define RNGS_H

#ifdef __cplusplus
extern "C" {
#endif

/* -----------------------------------------------------------------------
 * Name            : rngs.h  (header file for the library file rngs.c)
 * Author          : Steve Park & Dave Geyer
 * Language        : ANSI C
 * Latest Revision : 09-22-98
 * -----------------------------------------------------------------------
 */

#if !defined( _RNGS_ )
#define _RNGS_

double Random(void);
void   PlantSeeds(long x);
void   GetSeed(long *x);
void   PutSeed(long x);
void   SelectStream(int index);
void   TestRandom(void);

#endif


#ifdef __cplusplus
}
#endif

#endif /* RNGS_H */


#endif /* RNGS_H_ */
