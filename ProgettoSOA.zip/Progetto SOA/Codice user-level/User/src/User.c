/*
 ============================================================================
 Name        : SOP.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <pthread.h>
#include <error.h>
#include "MyCommands_ioctl.h"
#include "rngs.h"



#define SIZE_MSG 20
#define N_OPERATIONS_TO_DO 30
#define NAME_MY_DEV "/dev/my_device"

void LoadBalancer(int number_of_threads, int number_of_devices);
int equilikely(int a, int b);          //generate random number in [a, b] with the same probability
void *my_thread_function( void *ptr );

int *nth;  //array whose values are written by LoadBalancer

int main(int argc, char* argv[]) {


	int ret; // control variable to check return values
	int i; // simple counter in for loops
	int number_of_threads= atoi(argv[1]); // number of threads to create
	int *aux=(int *)malloc(number_of_threads*sizeof(int) );// integer id for threads

	int number_of_devices= atoi(argv[2]); // number of devices available

	printf("User-level threads created: %d\n",number_of_threads);
	printf("Number of devices available: %d\n",number_of_devices);

	nth =(int *)malloc(number_of_threads*sizeof(int) ); //nth is the array written by LoadBalancer function.
	LoadBalancer(number_of_threads, number_of_devices); //the index i of this array is thread number i.
                                                        //the value at position i is the device to use

    pthread_t *ths=(pthread_t*)malloc(number_of_threads*sizeof(pthread_t));

    for(i=0;i<number_of_threads;i++){
      aux[i]=i;
	  ret=pthread_create( &ths[i], NULL, my_thread_function, &(aux[i]) );
         if (ret<0){
    	    printf("thread create failed!!\n");
    	    return 0;
         }
    }


    for(i=0;i<number_of_threads;i++){
      pthread_join( ths[i], NULL);
    }


    printf("FINE MAIN\n");
	return EXIT_SUCCESS;
}

/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////

void *my_thread_function( void *ptr ){

	char msgToRead[SIZE_MSG];  //store read message from queue
	int resRead;               //variable to check return value of read()

	char msgToWrite[SIZE_MSG]="DataToWrite";  //store message to write in queue
	int resWrite;               //variable to check return value of write()

	int index= *((int*) ptr);    // index of thread when created
	int n_device=nth[index];     //number of device to open

	printf("thread%d  n_device: %d\n",index,n_device);

    int fd_dev;     // file descriptor
    char name_device[17];

	int ops[N_OPERATIONS_TO_DO];  //what the thread does is written in these array


	sprintf(name_device, "%s%d",NAME_MY_DEV, n_device);
	fd_dev=open( name_device ,O_RDWR);
	     if(fd_dev<0){
	    	 printf("Thread%d: file open %s failed fd_dev=%d !!\n",index,name_device,fd_dev);
	    	 perror("Error printed by perror");
	    	 return NULL;
	     }


    printf("Thread%d: file opened %s successfully!!\n",index,name_device);


///////////////////////////////////////////////////////////////////////////////////
	int rand; int i=0;

	long int x = -10; // x < 0 the clock of the system is used to generate random numbers
	PutSeed(x);

	for(i=0;i< N_OPERATIONS_TO_DO;i++){
	   rand=equilikely(0, 3);

	   ops[i]=rand;

	}//for

//////////////////////////////////////////////////////////


     sprintf(name_device, "%s%d",NAME_MY_DEV, n_device);
     fd_dev=open( name_device ,O_RDWR);
     if(fd_dev<0){
    	 printf("Thread%d: file open %s failed!!\n",index,name_device);
    	 perror("Error printed by perror");
    	 return NULL;
     }


	  printf("Thread%d: file opened %s successfully!!\n",index,name_device);


      for(i=0;i<N_OPERATIONS_TO_DO;i++){

         if(ops[i]==0){
        	 ioctl(fd_dev,BLOCKING_READ_HP);
         }



         if( ops[i]==1){
        	 ioctl(fd_dev,BLOCKING_READ_LP );

        	 resRead=read(fd_dev,msgToRead,SIZE_MSG);
        	 if(resRead<0){
        	    printf("Thread%d: read failed!!\n",index);

        	 }else{
        		printf("Thread%d: read msg:%s!!\n",index,msgToRead);
        	 }
         }



         if(ops[i]==2){
             ioctl(fd_dev,BLOCKING_WRITE);

             resWrite=write(fd_dev,msgToWrite,strlen(msgToWrite));
             if(resWrite<0){
            	 printf("Thread%d: blocking write failed!!\n",index);
             }else{
            	 printf("Thread%d: blocking write ok resWrite:%d !!\n",index,resWrite);
             }

         }



         if(ops[i]==3){
            ioctl(fd_dev,NOT_BLOCKING_WRITE);

            resWrite=write(fd_dev,msgToWrite,strlen(msgToWrite));
            if(resWrite<0){
                printf("Thread%d: not blocking write failed!!\n",index);
            }else{
            	printf("Thread%d: not blocking write ok resWrite:%d !!\n",index,resWrite);
            }

         }


      }//for


    close(fd_dev);
    printf("Thread%d closed \n",index);
	return NULL;
}

void LoadBalancer(int number_of_threads, int number_of_devices){

   int i;
   for(i=0;i<number_of_threads;i++){

	 nth[i]=(i%number_of_devices);
	 printf("LoadBalancer: %d ", nth[i]);
   }

   printf("\n");
}//loadBalancer


int equilikely(int a, int b){

	double u;
	u=Random();  // u is a random number between 0 and 1

	return a + (long) (u * (b - a + 1));
}


